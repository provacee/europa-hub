/* ============================================================
   EUROPA HUB v2 — Pages: Training · VEO · Tasks · Wellness · Selection
   ============================================================ */

// ── TRAINING ───────────────────────────────────────────────

function renderTraining() {
  const trainings = DB.trainings();
  return `
  <div class="page-header">
    <div class="page-header-left">
      <div class="page-title">Entrenaments</div>
      <div class="page-subtitle">${trainings.length} sessions creades</div>
    </div>
    <div class="page-actions">
      <button class="btn btn-primary" onclick="openTrainingModal()">${ico('plus')} Nova Sessió</button>
    </div>
  </div>
  <div style="display:flex;flex-direction:column;gap:14px">
    ${trainings.length===0
      ? `<div class="empty-state"><h3>Cap sessió creada</h3></div>`
      : trainings.map(t=>renderTrainingCard(t, true)).join('')}
  </div>
  <div id="training-modal-container"></div>
  `;
}

function renderTrainingCard(t, canEdit=false) {
  const teamColors = { all:'badge-blue', A:'badge-red', B:'badge-green', C:'badge-yellow' };
  const teamLabels = { all:'Tot l\'equip', A:'Equip A', B:'Equip B', C:'Equip C' };
  return `
  <div class="card">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
      <div style="flex:1">
        <div style="font-weight:600;font-size:.9375rem">${t.title}</div>
        <div style="font-size:.72rem;color:var(--text3)">${formatDate(t.date)}</div>
      </div>
      ${canEdit ? `
      <button class="btn btn-ghost btn-sm" onclick="openTrainingModal('${t.id}')">${ico('edit')} Editar</button>
      <button class="btn btn-danger btn-sm" onclick="deleteTraining('${t.id}')">${ico('trash')}</button>
      ` : ''}
    </div>
    <div style="display:flex;flex-direction:column;gap:6px">
      ${t.tasks.map((task,i) => `
      <div style="display:flex;align-items:center;gap:10px;padding:9px 12px;background:var(--bg3);border-radius:6px;border:1px solid var(--border)">
        <div style="width:22px;height:22px;background:var(--brand-dim);color:var(--brand);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.65rem;font-weight:700;flex-shrink:0">${i+1}</div>
        <div style="flex:1;min-width:0">
          <div style="font-size:.8125rem;font-weight:500">${task.name}</div>
          ${task.notes ? `<div style="font-size:.7rem;color:var(--text3)">${task.notes}</div>` : ''}
        </div>
        <span class="badge ${teamColors[task.team||'all']}">${teamLabels[task.team||'all']}</span>
        <div style="font-size:.75rem;color:var(--text2);flex-shrink:0;font-weight:500">${task.duration} min</div>
      </div>
      `).join('')}
    </div>
    <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--border);display:flex;align-items:center;gap:8px;font-size:.75rem;color:var(--text3)">
      Durada total: <strong style="color:var(--text)">${t.tasks.reduce((s,tk)=>s+tk.duration,0)} min</strong>
    </div>
  </div>
  `;
}

function openTrainingModal(id=null) {
  const trainings = DB.trainings();
  const t = id ? trainings.find(tr=>tr.id===id) : null;
  const tasks = t ? t.tasks : [{ name:'', duration:15, notes:'', team:'all' }];

  document.getElementById('training-modal-container').innerHTML = `
  <div class="modal-overlay" id="training-modal">
    <div class="modal modal-lg">
      <div class="modal-header">
        <div class="modal-title">${t ? 'Editar Sessió' : 'Nova Sessió'}</div>
        <button class="btn-icon" onclick="closeModal('training-modal')">${ico('close')}</button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <div class="form-group"><label class="form-label">Títol</label><input class="form-input" id="tr-title" value="${t?.title||''}"></div>
          <div class="form-group"><label class="form-label">Data</label><input class="form-input" type="date" id="tr-date" value="${t?.date||new Date().toISOString().split('T')[0]}"></div>
        </div>
        <div>
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="font-size:.7rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--text2)">Tasques</span>
            <button class="btn btn-ghost btn-sm" type="button" onclick="addTrainingTask()">${ico('plus')} Afegir</button>
          </div>
          <div id="training-tasks">
            ${tasks.map((task,i)=>renderTrainingTaskRow(task,i)).join('')}
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('training-modal')">Cancel·lar</button>
        <button class="btn btn-primary" onclick="saveTraining('${id||''}')">Desar</button>
      </div>
    </div>
  </div>`;
}

function renderTrainingTaskRow(task, i) {
  const teams = ['all','A','B','C'];
  const teamLabels = { all:"Tot l'equip", A:'Equip A', B:'Equip B', C:'Equip C' };
  return `
  <div class="training-task-row" data-idx="${i}" style="display:grid;grid-template-columns:1fr 70px 1fr 110px auto;gap:6px;margin-bottom:6px;align-items:center">
    <input class="form-input" placeholder="Nom tasca" value="${task.name||''}" data-field="name">
    <input class="form-input" type="number" placeholder="min" value="${task.duration||15}" data-field="duration" style="text-align:center">
    <input class="form-input" placeholder="Notes" value="${task.notes||''}" data-field="notes">
    <select class="form-select" data-field="team">
      ${teams.map(tm=>`<option value="${tm}" ${(task.team||'all')===tm?'selected':''}>${teamLabels[tm]}</option>`).join('')}
    </select>
    <button class="btn-icon btn-sm" onclick="removeTrainingTask(${i})" style="color:var(--brand)">${ico('trash')}</button>
  </div>`;
}

function addTrainingTask() {
  const container = document.getElementById('training-tasks');
  const rows = container.querySelectorAll('.training-task-row');
  const div = document.createElement('div');
  div.innerHTML = renderTrainingTaskRow({name:'',duration:15,notes:'',team:'all'}, rows.length);
  container.appendChild(div.firstElementChild);
}

function removeTrainingTask(idx) {
  const rows = document.querySelectorAll('.training-task-row');
  if (rows.length <= 1) return;
  rows[idx]?.remove();
}

function saveTraining(id) {
  const title = document.getElementById('tr-title').value.trim();
  const date  = document.getElementById('tr-date').value;
  if (!title) { toast('Títol obligatori','error'); return; }
  const rows = document.querySelectorAll('.training-task-row');
  const tasks = Array.from(rows).map(row => ({
    name:     row.querySelector('[data-field="name"]').value.trim(),
    duration: parseInt(row.querySelector('[data-field="duration"]').value)||0,
    notes:    row.querySelector('[data-field="notes"]').value.trim(),
    team:     row.querySelector('[data-field="team"]').value,
  })).filter(t=>t.name);
  const data = { title, date, tasks };
  const trainings = DB.trainings();
  if (id) { const i=trainings.findIndex(t=>t.id===id); if(i!==-1) trainings[i]={...trainings[i],...data}; }
  else trainings.unshift({ id:uid(),...data });
  DB.saveTrainings(trainings);
  closeModal('training-modal');
  toast('Sessió desada','success');
  navigate('training');
}

function deleteTraining(id) {
  if (!confirm('Eliminar sessió?')) return;
  DB.saveTrainings(DB.trainings().filter(t=>t.id!==id));
  toast('Sessió eliminada','success');
  navigate('training');
}

function renderPlayerTraining() {
  const trainings = DB.trainings();
  return `
  <div class="page-header">
    <div class="page-header-left"><div class="page-title">Entrenaments</div><div class="page-subtitle">Sessions assignades</div></div>
  </div>
  <div style="display:flex;flex-direction:column;gap:14px">
    ${trainings.map(t=>renderTrainingCard(t, false)).join('')}
  </div>`;
}

// ── VEO ────────────────────────────────────────────────────

function renderVEO() {
  const videos = DB.videos();
  const cats = ['all','attack','defence','transition','set_pieces'];
  const catLabels = { all:'Tots', attack:'Atac', defence:'Defensa', transition:'Transició', set_pieces:'Pilota aturada' };
  return `
  <div class="page-header">
    <div class="page-header-left"><div class="page-title">Anàlisi VEO</div><div class="page-subtitle">Biblioteca de vídeos tàctics</div></div>
    <div class="page-actions"><button class="btn btn-primary" onclick="openVideoModal()">${ico('plus')} Afegir Vídeo</button></div>
  </div>
  <div class="chips" id="veo-filter" style="margin-bottom:18px">
    ${cats.map(c=>`<div class="chip ${c==='all'?'active':''}" data-cat="${c}">${catLabels[c]}</div>`).join('')}
  </div>
  <div class="grid grid-auto" id="veo-grid">
    ${videos.map(v=>renderVideoCard(v, true)).join('')}
  </div>
  <div id="video-modal-container"></div>`;
}

function renderVideoCard(v, canEdit=false) {
  const catColors = { attack:'var(--brand)', defence:'var(--blue)', transition:'var(--yellow)', set_pieces:'var(--green)' };
  const catLabels = { attack:'Atac', defence:'Defensa', transition:'Transició', set_pieces:'Pilota aturada' };
  return `
  <div class="video-card" data-cat="${v.category}">
    <div class="video-thumb">
      <div style="position:absolute;inset:0;background:linear-gradient(135deg,${catColors[v.category]||'var(--brand)'}20,var(--bg3));display:flex;align-items:center;justify-content:center">
        <div class="play-btn">${ico('play')}</div>
      </div>
    </div>
    <div class="video-info">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px">
        <div class="video-title">${v.title}</div>
        ${canEdit ? `<button class="btn-icon btn-sm" onclick="deleteVideo('${v.id}')" style="color:var(--brand)">${ico('trash')}</button>` : ''}
      </div>
      <div class="video-meta">${v.description}</div>
      <div style="margin-top:7px;display:flex;align-items:center;justify-content:space-between">
        <span class="badge" style="background:${catColors[v.category]||'var(--brand)'}18;color:${catColors[v.category]||'var(--brand)'}">${catLabels[v.category]||v.category}</span>
        <span style="font-size:.68rem;color:var(--text3)">${formatDate(v.date)}</span>
      </div>
    </div>
  </div>`;
}

function openVideoModal() {
  document.getElementById('video-modal-container').innerHTML = `
  <div class="modal-overlay" id="video-modal">
    <div class="modal">
      <div class="modal-header"><div class="modal-title">Nou Vídeo</div><button class="btn-icon" onclick="closeModal('video-modal')">${ico('close')}</button></div>
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Títol</label><input class="form-input" id="v-title"></div>
        <div class="form-group"><label class="form-label">Categoria</label>
          <select class="form-select" id="v-cat"><option value="attack">Atac</option><option value="defence">Defensa</option><option value="transition">Transició</option><option value="set_pieces">Pilota Aturada</option></select>
        </div>
        <div class="form-group"><label class="form-label">Descripció</label><textarea class="form-textarea" id="v-desc" style="min-height:60px"></textarea></div>
        <div class="form-group"><label class="form-label">URL del vídeo</label><input class="form-input" id="v-url" placeholder="https://..."></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('video-modal')">Cancel·lar</button>
        <button class="btn btn-primary" onclick="saveVideo()">Afegir</button>
      </div>
    </div>
  </div>`;
}

function saveVideo() {
  const title = document.getElementById('v-title').value.trim();
  if (!title) { toast('Títol obligatori','error'); return; }
  const videos = DB.videos();
  videos.unshift({ id:uid(), title, category:document.getElementById('v-cat').value, description:document.getElementById('v-desc').value.trim(), url:document.getElementById('v-url').value.trim(), date:new Date().toISOString().split('T')[0] });
  DB.saveVideos(videos);
  closeModal('video-modal');
  toast('Vídeo afegit','success');
  navigate('veo');
}

function deleteVideo(id) {
  if (!confirm('Eliminar vídeo?')) return;
  DB.saveVideos(DB.videos().filter(v=>v.id!==id));
  toast('Vídeo eliminat','success');
  navigate('veo');
}

function renderPlayerVEO() {
  const videos = DB.videos();
  return `
  <div class="page-header"><div class="page-header-left"><div class="page-title">Anàlisi VEO</div><div class="page-subtitle">Vídeos tàctics de l'equip</div></div></div>
  <div class="grid grid-auto">${videos.map(v=>renderVideoCard(v, false)).join('')}</div>`;
}

// ── TASKS ──────────────────────────────────────────────────

function renderTasks() {
  const tasks = DB.tasks();
  const users = DB.users();
  const groups = { todo:'Pendent', in_progress:'En curs', done:'Fet' };
  const dotColors = { todo:'var(--text3)', in_progress:'var(--yellow)', done:'var(--green)' };

  return `
  <div class="page-header">
    <div class="page-header-left"><div class="page-title">Tasques Staff</div><div class="page-subtitle">${tasks.filter(t=>t.status!=='done').length} pendents</div></div>
    <div class="page-actions"><button class="btn btn-primary" onclick="openTaskModal()">${ico('plus')} Nova Tasca</button></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;align-items:start">
    ${Object.entries(groups).map(([status,label]) => {
      const st = tasks.filter(t=>t.status===status);
      return `
      <div>
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px">
          <div style="width:7px;height:7px;border-radius:50%;background:${dotColors[status]}"></div>
          <span style="font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.09em;color:var(--text3)">${label}</span>
          <span class="badge badge-gray">${st.length}</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px">
          ${st.map(t=>renderTaskCard(t,users)).join('')}
          ${st.length===0 ? `<div style="padding:18px;text-align:center;color:var(--text3);font-size:.78rem;background:var(--bg2);border-radius:6px;border:1px dashed var(--border)">Cap tasca</div>` : ''}
        </div>
      </div>`;
    }).join('')}
  </div>
  <div id="task-modal-container"></div>`;
}

function renderTaskCard(t, users) {
  const a = users.find(u=>u.id===t.assignedTo);
  return `
  <div class="card card-sm" style="cursor:pointer" onclick="openTaskModal('${t.id}')">
    <div style="font-size:.8125rem;font-weight:500;margin-bottom:5px">${t.title}</div>
    <div style="font-size:.72rem;color:var(--text3);margin-bottom:8px">${t.description}</div>
    <div style="display:flex;align-items:center;gap:6px">
      ${a ? `<div class="avatar sm">${a.avatar}</div><span style="font-size:.72rem;color:var(--text3)">${a.name.split(' ')[0]}</span>` : ''}
      <span style="margin-left:auto;font-size:.7rem;color:var(--text3)">${t.dueDate ? formatDate(t.dueDate) : ''}</span>
    </div>
  </div>`;
}

function openTaskModal(id=null) {
  const users = DB.users();
  const tasks = DB.tasks();
  const t = id ? tasks.find(tk=>tk.id===id) : null;
  document.getElementById('task-modal-container').innerHTML = `
  <div class="modal-overlay" id="task-modal">
    <div class="modal">
      <div class="modal-header"><div class="modal-title">${t?'Editar Tasca':'Nova Tasca'}</div><button class="btn-icon" onclick="closeModal('task-modal')">${ico('close')}</button></div>
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Títol</label><input class="form-input" id="tk-title" value="${t?.title||''}"></div>
        <div class="form-group"><label class="form-label">Descripció</label><textarea class="form-textarea" id="tk-desc">${t?.description||''}</textarea></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Assignat a</label>
            <select class="form-select" id="tk-user">${users.map(u=>`<option value="${u.id}" ${t?.assignedTo===u.id?'selected':''}>${u.name}</option>`).join('')}</select>
          </div>
          <div class="form-group"><label class="form-label">Data límit</label><input class="form-input" type="date" id="tk-due" value="${t?.dueDate||''}"></div>
        </div>
        <div class="form-group"><label class="form-label">Estat</label>
          <select class="form-select" id="tk-status">
            <option value="todo" ${(!t||t.status==='todo')?'selected':''}>Pendent</option>
            <option value="in_progress" ${t?.status==='in_progress'?'selected':''}>En curs</option>
            <option value="done" ${t?.status==='done'?'selected':''}>Fet</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        ${t ? `<button class="btn btn-danger btn-sm" onclick="deleteTask('${t.id}')">${ico('trash')} Eliminar</button>` : ''}
        <button class="btn btn-ghost" onclick="closeModal('task-modal')">Cancel·lar</button>
        <button class="btn btn-primary" onclick="saveTask('${id||''}')">Desar</button>
      </div>
    </div>
  </div>`;
}

function saveTask(id) {
  const title = document.getElementById('tk-title').value.trim();
  if (!title) { toast('Títol obligatori','error'); return; }
  const data = { title, description:document.getElementById('tk-desc').value.trim(), assignedTo:document.getElementById('tk-user').value, dueDate:document.getElementById('tk-due').value, status:document.getElementById('tk-status').value, comments:[] };
  const tasks = DB.tasks();
  if (id) { const i=tasks.findIndex(t=>t.id===id); if(i!==-1) tasks[i]={...tasks[i],...data}; }
  else tasks.push({ id:uid(),...data });
  DB.saveTasks(tasks);
  closeModal('task-modal');
  toast('Tasca desada','success');
  navigate('tasks');
}

function deleteTask(id) {
  if (!confirm('Eliminar tasca?')) return;
  DB.saveTasks(DB.tasks().filter(t=>t.id!==id));
  closeModal('task-modal');
  toast('Tasca eliminada','success');
  navigate('tasks');
}

// ── WELLNESS ───────────────────────────────────────────────

function renderWellness() {
  const players = DB.players();
  const wellness = DB.wellness();
  const today = new Date().toISOString().split('T')[0];
  return `
  <div class="page-header">
    <div class="page-header-left"><div class="page-title">Wellness</div><div class="page-subtitle">Estat físic dels jugadors · ${formatDate(today)}</div></div>
  </div>
  <div class="card">
    <div style="display:grid;grid-template-columns:1fr 58px 58px 58px 64px 56px;gap:0;align-items:center;padding-bottom:10px;margin-bottom:4px;border-bottom:1px solid var(--border)">
      ${['Jugador','Son','Fatiga','Dolor','Condició','Fisio'].map((h,i)=>`<div style="font-size:.65rem;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--text3);${i>0?'text-align:center':''}">${h}</div>`).join('')}
    </div>
    ${players.map(p => {
      const w = wellness[p.id]?.[0];
      return `
      <div style="display:grid;grid-template-columns:1fr 58px 58px 58px 64px 56px;gap:0;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:8px">
          <div class="avatar sm">${(p.name[0]+p.surname[0]).toUpperCase()}</div>
          <div><div style="font-size:.8125rem;font-weight:500">${p.name} ${p.surname}</div><div style="font-size:.68rem;color:var(--text3)">${p.position}</div></div>
        </div>
        ${w ? `
          <div class="score-circle ${scoreColor(w.sleep,9)}" style="justify-self:center">${w.sleep}h</div>
          <div class="score-circle ${scoreColor(10-w.fatigue,10)}" style="justify-self:center">${w.fatigue}</div>
          <div class="score-circle ${scoreColor(10-w.soreness,10)}" style="justify-self:center">${w.soreness}</div>
          <div class="score-circle ${scoreColor(w.condition,10)}" style="justify-self:center">${w.condition}</div>
          <div style="text-align:center">${w.physio ? `<span class="badge badge-red">Sí</span>` : `<span class="badge badge-green">No</span>`}</div>
        ` : `<div style="grid-column:2/-1;font-size:.72rem;color:var(--text3);text-align:center">Sense dades avui</div>`}
      </div>`;
    }).join('')}
  </div>`;
}

function renderPlayerWellness() {
  const wellness = DB.wellness();
  const pid = currentUser.role === 'player' ? 'p4' : 'p8';
  const entries = wellness[pid] || [];
  const today = new Date().toISOString().split('T')[0];
  const todayEntry = entries.find(e=>e.date===today);
  return `
  <div class="page-header">
    <div class="page-header-left"><div class="page-title">Wellness</div><div class="page-subtitle">Qüestionari diari · ${formatDate(today)}</div></div>
  </div>
  ${todayEntry ? `<div style="padding:10px 14px;background:var(--green-dim);border:1px solid rgba(34,197,94,.3);border-radius:6px;margin-bottom:16px;font-size:.8125rem;color:var(--green);display:flex;align-items:center;gap:7px">${ico('check')} Qüestionari d'avui completat!</div>` : ''}
  <div class="card" style="max-width:480px">
    <div style="font-family:var(--font-display);font-size:1.2rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-bottom:18px">Qüestionari Diari</div>
    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="form-group"><label class="form-label">Hores de son</label><input class="form-input" type="number" id="w-sleep" min="0" max="12" step="0.5" value="${todayEntry?.sleep||7}" style="max-width:120px"></div>
      ${[{key:'fatigue',label:'Fatiga',hint:'1=res · 10=molt cansat'},{key:'soreness',label:'Dolor muscular',hint:'1=res · 10=molt dolor'},{key:'condition',label:'Condició física',hint:'1=molt malament · 10=excel·lent'}].map(item=>`
      <div class="form-group">
        <label class="form-label">${item.label}</label>
        <div class="score-dots" id="dots-${item.key}">
          ${Array.from({length:10},(_,i)=>`<div class="score-dot ${todayEntry?.[item.key]===i+1?'active':''}" data-val="${i+1}" onclick="setScore('${item.key}',${i+1})">${i+1}</div>`).join('')}
        </div>
        <div class="form-hint">${item.hint}</div>
      </div>`).join('')}
      <div class="form-group">
        <label class="form-label">Necessites fisioteràpia?</label>
        <div style="display:flex;gap:12px">
          <label style="display:flex;align-items:center;gap:5px;cursor:pointer;font-size:.8125rem"><input type="radio" name="w-physio" value="yes" ${todayEntry?.physio?'checked':''}>Sí</label>
          <label style="display:flex;align-items:center;gap:5px;cursor:pointer;font-size:.8125rem"><input type="radio" name="w-physio" value="no" ${!todayEntry||!todayEntry.physio?'checked':''}>No</label>
        </div>
      </div>
      <div class="form-group"><label class="form-label">Comentaris</label><textarea class="form-textarea" id="w-comments">${todayEntry?.comments||''}</textarea></div>
    </div>
    <button class="btn btn-primary" style="margin-top:18px;width:100%" onclick="saveWellness()">Enviar Qüestionari</button>
  </div>`;
}

const _wellnessScores = {};
function setScore(key, val) {
  _wellnessScores[key] = val;
  document.querySelectorAll(`#dots-${key} .score-dot`).forEach(d => d.classList.toggle('active', parseInt(d.dataset.val)===val));
}

function saveWellness() {
  const pid = 'p4';
  const today = new Date().toISOString().split('T')[0];
  const wellness = DB.wellness();
  if (!wellness[pid]) wellness[pid] = [];
  const entry = {
    date: today,
    sleep:     parseFloat(document.getElementById('w-sleep').value)||7,
    fatigue:   _wellnessScores.fatigue   || 5,
    soreness:  _wellnessScores.soreness  || 5,
    condition: _wellnessScores.condition || 7,
    physio:    document.querySelector('input[name="w-physio"]:checked')?.value==='yes',
    comments:  document.getElementById('w-comments').value.trim(),
  };
  wellness[pid] = [entry, ...wellness[pid].filter(e=>e.date!==today)];
  DB.saveWellness(wellness);
  toast('Qüestionari enviat!','success');
  navigate('player_wellness');
}

// ── SQUAD SELECTION ────────────────────────────────────────
// Editable only from Àrea Esportiva 1 (coaches, admin, director)
// Players see read-only in Àrea Esportiva 2

function renderSelection() {
  const sel = DB.selection();
  const players = DB.players();
  const isCoach = ['coach','administrator','sporting_director'].includes(currentUser.role);

  const selected    = players.filter(p=>sel.selected.includes(p.id));
  const notSelected = players.filter(p=>sel.notSelected.includes(p.id));

  return `
  <div class="page-header">
    <div class="page-header-left">
      <div class="page-title">Convocatòria</div>
      <div class="page-subtitle">${sel.published ? `<span class="badge badge-green">${ico('check')} Publicada</span>` : `<span class="badge badge-gray">Esborrany</span>`}</div>
    </div>
    <div class="page-actions">
      ${isCoach ? (sel.published
        ? `<button class="btn btn-ghost" onclick="togglePublish()">Despublicar</button>`
        : `<button class="btn btn-primary" onclick="togglePublish()">${ico('publish')} Publicar</button>`)
      : ''}
    </div>
  </div>

  ${isCoach ? `<div style="padding:10px 12px;background:var(--bg3);border-radius:6px;border:1px solid var(--border);font-size:.78rem;color:var(--text2);margin-bottom:16px">Fes clic a un jugador per moure'l d'una columna a l'altra.</div>` : ''}

  <div class="selection-grid">
    <div class="selection-column">
      <div class="selection-col-header selected">${ico('check')} Convocat (${selected.length})</div>
      ${selected.map(p=>`
      <div class="selection-player" ${isCoach?`onclick="togglePlayerSelection('${p.id}',true)"`:''} style="${!isCoach?'cursor:default':''}">
        <div class="shirt-num">${p.number}</div>
        <div style="flex:1"><div style="font-weight:500">${p.name} ${p.surname}</div><div style="font-size:.7rem;color:var(--text3)">${p.position}</div></div>
        ${isCoach?`<span style="color:var(--text3);font-size:.75rem">→</span>`:''}
      </div>`).join('')}
    </div>
    <div class="selection-column">
      <div class="selection-col-header not-selected">${ico('close')} No convocat (${notSelected.length})</div>
      ${notSelected.map(p=>`
      <div class="selection-player" ${isCoach?`onclick="togglePlayerSelection('${p.id}',false)"`:''} style="opacity:.55;${!isCoach?'cursor:default':''}">
        <div class="shirt-num" style="background:var(--border2)">${p.number}</div>
        <div style="flex:1"><div style="font-weight:500">${p.name} ${p.surname}</div><div style="font-size:.7rem;color:var(--text3)">${p.position}</div></div>
        ${isCoach?`<span style="color:var(--text3);font-size:.75rem">←</span>`:''}
      </div>`).join('')}
    </div>
  </div>`;
}

function togglePlayerSelection(pid, isCurrentlySelected) {
  const sel = DB.selection();
  if (isCurrentlySelected) {
    sel.selected    = sel.selected.filter(id=>id!==pid);
    sel.notSelected = [...sel.notSelected, pid];
  } else {
    sel.notSelected = sel.notSelected.filter(id=>id!==pid);
    sel.selected    = [...sel.selected, pid];
  }
  DB.saveSelection(sel);
  navigate('selection');
}

function togglePublish() {
  const sel = DB.selection();
  sel.published = !sel.published;
  DB.saveSelection(sel);
  toast(sel.published ? 'Convocatòria publicada!' : 'Convocatòria despublicada', sel.published?'success':'info');
  navigate('selection');
}

function renderPlayerSelection() {
  const sel = DB.selection();
  if (!sel.published) {
    return `
    <div class="page-header"><div class="page-header-left"><div class="page-title">Convocatòria</div></div></div>
    <div class="empty-state"><h3>Convocatòria no publicada</h3><p>L'entrenador encara no ha publicat la convocatòria</p></div>`;
  }
  const players = DB.players();
  const selected = players.filter(p=>sel.selected.includes(p.id));
  return `
  <div class="page-header">
    <div class="page-header-left"><div class="page-title">Convocatòria</div><div class="page-subtitle"><span class="badge badge-green">Publicada</span></div></div>
  </div>
  <div class="card" style="max-width:460px">
    <div style="margin-bottom:14px;font-size:.8125rem;font-weight:600">Jugadors convocats (${selected.length})</div>
    ${selected.map(p=>`
    <div style="display:flex;align-items:center;gap:9px;padding:9px 0;border-bottom:1px solid var(--border)">
      <div class="shirt-num">${p.number}</div>
      <div><div style="font-weight:500;font-size:.8125rem">${p.name} ${p.surname}</div><div style="font-size:.7rem;color:var(--text3)">${p.position}</div></div>
    </div>`).join('')}
  </div>`;
}
